###############################################################################################
############################# Achilles Tendon Study ###########################################
################################# ADF 9/8/2020 ################################################
############################## afoster[at]campbell[dot]edu ####################################

#Load packages

library(ggplot2)
library(emmeans)
library(lsmeans)
library(nlme)
library(tidyverse)
library(dplyr)
library(plyr)
library(ggplot2)
library(ggridges)
library(naniar)
library(cowplot)
library(grid)
library(tcltk)

#_____LOCATE ACHILLES FOLDER STRUCTURE_____________________________________________________________.

# After unzipping Achilles folder from Github (https://github.com/adfoster/achillestendon) tell R where this folder lives
#This was written for Windows. If you are using another OS, it's possible these routines won't work

#Locate Achilles folder location:
#NOTE - THE WINDOW WHICH ALLOWS YOU TO SELECT THE 'ACHILLES' FOLDER WILL POP UNDER THE RSTUDIO WINDOW - MINIMIZE R TO LOCATE
achilles.folder.loc = tk_choose.dir(caption = "Choose the Achilles folder location")
setwd(achilles.folder.loc)

#Uses file path to determine if Tables folder exists in Achilles folder, if not, it will create one
#All tables output as CSV files will go here
ifelse(!dir.exists(file.path(achilles.folder.loc, 'Tables')), dir.create(file.path(achilles.folder.loc, 'Tables')), FALSE)

#Uses file path to determine if Figures folder exists in Achilles folder, if not, it will create one
#All figures output as tiff files will go here
ifelse(!dir.exists(file.path(achilles.folder.loc, 'Figures')), dir.create(file.path(achilles.folder.loc, 'Figures')), FALSE)


#_____IMPORT MORPHOMETRIC DATA_____________________________________________________________________.

#set morph file location from file path
morph.dir = file.path(achilles.folder.loc,'Morphometrics') 
morph.files=dir(morph.dir,pattern='*.csv',full.names=T)

morph.data=data.frame()

#This runs through all the files, extracts data, and puts it into a single dataframe
for (i in 1:length(morph.files)) {
  
  temp.file.name=morph.files[i]
  print(temp.file.name)
  temp.dat=read.csv(temp.file.name,skip=1,header=F)
  names(temp.dat)=c('Subject','age','sex','bm','height','hip.height_L','hip.height_R',
                    'foot.length_L','foot.length_R','tendon.length_L','tendon.length_R')
  temp.dat$id=NULL
  temp.metadata=strsplit(temp.file.name,'_',fixed=T)[[1]][1]
  temp.metadata.parts=strsplit(temp.metadata,'/',fixed=T)
  temp.metadata.id=sapply(temp.metadata.parts,tail,1)
  temp.dat$Subject=temp.metadata.id
  morph.data=rbind(morph.data,temp.dat) 
}

#Make New Variables

morph.data$hip.height=(morph.data$hip.height_L+morph.data$hip.height_R)/2
morph.data$foot.length=(morph.data$foot.length_L+morph.data$foot.length_R)/2
morph.data$tendon.length=(morph.data$tendon.length_L+morph.data$tendon.length_R)/2

#_____IMPORT ULTRASOUND DATA_____________________________________________________________________.

imagej.dir = file.path(achilles.folder.loc,'ImageJ') 
imagej.files=dir(imagej.dir,pattern='*.csv',full.names=T)

imagej.data=data.frame()

#This runs through all the files, extracts data, and puts it into a single dataframe
for (i in 1:length(imagej.files)) {
  temp.file.name=imagej.files[i]
  print(temp.file.name)
  temp.dat=read.csv(temp.file.name,skip=1,header=F)
  names(temp.dat)=c('Subject','Left_Ank_Lat_MA','Left_Ank_Med_MA','Right_Ank_Lat_MA',
                    'Right_Ank_Med_MA','Skin_Depth_Left','Skin_Depth_Right','Left_Tendon_ML',
                    'Left_Tendon_AP','Left_Area','Right_Tendon_ML','Right_Tendon_AP','Right_Area')
  temp.dat$id=NULL
  temp.metadata=strsplit(temp.file.name,'_',fixed=T)[[1]][1]
  temp.metadata.parts=strsplit(temp.metadata,'/',fixed=T)
  temp.metadata.id=sapply(temp.metadata.parts,tail,1)
  temp.dat$Subject=temp.metadata.id
  imagej.data=rbind(imagej.data,temp.dat) 
}


#Remove skin depth
imagej.data = subset(imagej.data, select=-c(Skin_Depth_Right,Skin_Depth_Left))

#Create new variables

imagej.data$tendon.area=(imagej.data$Left_Area+imagej.data$Right_Area)/2

imagej.data$tendon.ml=(imagej.data$Left_Tendon_ML+imagej.data$Right_Tendon_ML)/2

imagej.data$tendon.ap=(imagej.data$Left_Tendon_AP+imagej.data$Right_Tendon_AP)/2

imagej.data$tendon.elipse=pi*(imagej.data$tendon.ml/2)*(imagej.data$tendon.ap/2)

imagej.data$ankma=(imagej.data$Left_Ank_Lat_MA+imagej.data$Left_Ank_Med_MA+imagej.data$Right_Ank_Lat_MA+imagej.data$Right_Ank_Med_MA)/4

#_____IMPORT LOCOMOTOR MECHANIC DATA_____________________________________________________________________.

mech.dir = file.path(achilles.folder.loc,'Processed Data') 

mech.folders=dir(mech.dir)
mech.data=data.frame()

#This runs through all the subject folders and lists them
for (i in 1:length(mech.folders)) {
  temp.subject.folder=mech.folders[i]
  print(temp.subject.folder)
  temp.subject.dir=paste(mech.dir,'/',temp.subject.folder,sep='')
  setwd(temp.subject.dir)
  temp.files=dir(temp.subject.dir,pattern='*.csv',full.names=T)
  temp.files=temp.files[-grep('*Results_100*',temp.files)]
  
  #This runs through all the files, extracts data, and puts it into a single dataframe
  for (k in 1:length(temp.files)) {
    temp.file.name=temp.files[k]
    print(temp.file.name)
    temp.dat=read.csv(temp.file.name,skip=1,header=F)
    names(temp.dat)=c('velocity', 'toc','meanThighLength',
                      'meanShankLength', 'meanFootLength','impulseHip','total_hipWork_2','maxHip', 'maxHipForce', 'impulseKnee',
                      'total_kneeWork_2', 'maxKnee', 'maxKneeForce','impulseAnk','total_ankWork_2','maxAnk','maxAnkForce',
                      'AreaHip','AreaKnee', 'AreaAnk','AreaGRF','maxHipAng','minHipAng','maxKneeAng','minKneeAng','maxAnkleAng','minAnkleAng',
                      'avgHipAng','avgKneeAng','avgAnkAng','HipAngStdev','KneeAngStdev','AnkAngStdev','meanrHip','meanrKnee','meanrAnk',
                      'Froude','Froude_COL','total_hipWork','PosWork_hip','PosWorkScld_hip','NegWork_hip',
                      'NegWorkScld_hip','total_kneeWork','PosWork_knee','PosWorkScld_knee','NegWork_knee',
                      'NegWorkScld_knee','total_ankWork','PosWork_ank','NegWork_ank','NegWorkScld_ank')
    
    temp.metadata.filename=strsplit(temp.file.name,'/',fixed=T)
    temp.metadata=sapply(temp.metadata.filename,tail,1)
    temp.metadata.parts=strsplit(temp.metadata,'_',fixed=T)
    temp.metadata.subject=temp.metadata.parts[[1]][1]
    temp.dat$Subject=temp.metadata.subject
    temp.metadata.gait=temp.metadata.parts[[1]][2]
    temp.dat$Gait=temp.metadata.gait
    temp.metadata.side=strsplit(temp.metadata.parts[[1]][6],'.',fixed=T)[[1]][1]
    temp.dat$Side=temp.metadata.side
    temp.metadata.trial=temp.metadata.parts[[1]][3]
    temp.dat$Trial=temp.metadata.trial
    mech.data=rbind(mech.data,temp.dat)
    
  }}

#Recode side variables to match other datasets
mech.data$Side[mech.data$Side=='left'] <- "L"
mech.data$Side[mech.data$Side=='right'] <- "R"

mech.data$Gait[mech.data$Gait=='Walk'] <- "Walking"

#Remove duplicated columns
mech.data <- mech.data[ -c(7)]
mech.data <- mech.data[ -c(11)]
mech.data <- mech.data[ -c(15)]

#_____IMPORT LOCOMOTOR DATA SCALED TO 100% OF STEP________________________________________________.

interp.mech.dir = file.path(achilles.folder.loc,'Processed Data') 

interp.mech.folders=dir(interp.mech.dir)
interp.mech.data=data.frame()
peak.mech.data=data.frame()

#This runs through all the subject folders and lists them
for (i in 1:length(interp.mech.folders)) {
  temp.subject.folder=interp.mech.folders[i]
  print(temp.subject.folder)
  temp.subject.dir=paste(interp.mech.dir,'/',temp.subject.folder,sep='')
  setwd(temp.subject.dir)
  temp.files=dir(temp.subject.dir,pattern='*.csv',full.names=T)
  temp.files=temp.files[grep('*Results_100*',temp.files)]
  
  #This runs through all the files, extracts the interpolated data (standardized to 1-100% of stance phase), and puts it into a single dataframe
  for (k in 1:length(temp.files)) {
    temp.file.name=temp.files[k]
    print(temp.file.name)
    temp.interp.dat=read.csv(temp.file.name,skip=1,header=F)
    
    temp.metadata.filename=strsplit(temp.file.name,'/',fixed=T)
    temp.metadata=sapply(temp.metadata.filename,tail,1)
    temp.metadata.parts=strsplit(temp.metadata,'_',fixed=T)
    temp.metadata.subject=temp.metadata.parts[[1]][1]
    temp.interp.dat$Subject=temp.metadata.subject
    temp.metadata.gait=temp.metadata.parts[[1]][2]
    temp.interp.dat$Gait=temp.metadata.gait
    temp.metadata.side=strsplit(temp.metadata.parts[[1]][7],'.',fixed=T)[[1]][1]
    temp.interp.dat$Side=temp.metadata.side
    temp.metadata.trial=temp.metadata.parts[[1]][3]
    temp.interp.dat$Trial=temp.metadata.trial
    
    names(temp.interp.dat)=c('GRFraw100','hipAng100','kneeAng100','ankAng100','GRF100','FxFootP100','FyFootP100','MfootP100',
                             'FxShankP100','FyShankP100','FxShankD100','FyShankD100','MshankD100','MshankP100','FxThighP100',
                             'FyThighP100','FxThighD100','FyThighD100','MthighD100','MthighP100',
                             'hipPower100','kneePower100','ankPower100','HipForce100','KneeForce100','AnkForce100','Subject','Gait','Side','Trial')
    
    subset.temp.dat=subset(temp.interp.dat,select=c("Subject","Gait","Side","Trial","ankPower100"))
    subset.temp.dat$Percstep=seq(1,100)
    
    #Replace NaN values with 0 for Hip, Knee, and Ankle Force
    temp.interp.dat$AnkForce100[temp.interp.dat$AnkForce100=='NaN'] <- "NA"
    temp.interp.dat$HipForce100[temp.interp.dat$HipForce100=='NaN'] <- "NA"
    temp.interp.dat$KneeForce100[temp.interp.dat$KneeForce100=='NaN'] <- "NA"
    
    #Create temp data frame for peak values
    temp.ag.data=setNames(data.frame(matrix(ncol=7,nrow=1)),c('Subject','Trial','Side','Gait','peak.AnkForce','peak.HipForce','peak.KneeForce'))
    temp.ag.data$peak.AnkForce=max(as.numeric(temp.interp.dat$AnkForce100),na.rm=TRUE)
    temp.ag.data$peak.HipForce=max(as.numeric(temp.interp.dat$HipForce100),na.rm=TRUE)
    temp.ag.data$peak.KneeForce=max(as.numeric(temp.interp.dat$KneeForce100),na.rm=TRUE)
    temp.ag.data$Subject=temp.interp.dat$Subject[1]
    temp.ag.data$Trial=temp.interp.dat$Trial[1]
    temp.ag.data$Gait=temp.interp.dat$Gait[1]
    temp.ag.data$Side=temp.interp.dat$Side[1]
    interp.mech.data=rbind(interp.mech.data,subset.temp.dat)
    peak.mech.data=rbind(peak.mech.data,temp.ag.data)
  }}

interp.mech.data$Side[interp.mech.data$Side=='left'] <- "L"
interp.mech.data$Side[interp.mech.data$Side=='right'] <- "R"

interp.mech.data$Gait[interp.mech.data$Gait=='Walk'] <- "Walking"

peak.mech.data$Side[peak.mech.data$Side=='left'] <- "L"
peak.mech.data$Side[peak.mech.data$Side=='right'] <- "R"

peak.mech.data$Gait[peak.mech.data$Gait=='Walk'] <- "Walking"

####################################################
## CREATE NEW VARIABLES & SUBSET & MERGE DATASETS ##
####################################################

achilles.mech.data=merge(mech.data,morph.data,all.x=T,all.y=T,by='Subject')

#Create new variable not calculated in MATLAB
achilles.mech.data$PosWorkScld_ank=achilles.mech.data$PosWork_ank/achilles.mech.data$bm

#Subset data and create area variable

bm.data=subset(morph.data,select=c('Subject','bm'))
imagej.data$tendon.area.sqm=imagej.data$tendon.area/10000
ank.ma.data=subset(imagej.data,select=c('Subject','ankma','tendon.area','tendon.area.sqm'))
ank.ma.data$tendon.area.sqm=ank.ma.data$tendon.area/10000
scaling.morph.data=subset(morph.data,select=c('Subject','bm','foot.length'))
ank.ma.only.data=subset(imagej.data,select=c('Subject','ankma'))

#Merge data
achilles.mech.data=merge(achilles.mech.data,ank.ma.data,all.x=T,all.y=T,by='Subject')
scaling.data=merge(scaling.morph.data,ank.ma.data,all.x=T,all.y=T,by='Subject')

#Create new variables

achilles.mech.data$hipSNW=with(achilles.mech.data,abs(NegWork_hip+PosWork_hip)/(abs(NegWork_hip)+abs(PosWork_hip)))
achilles.mech.data$kneeSNW=with(achilles.mech.data,abs(NegWork_knee+PosWork_knee)/(abs(NegWork_knee)+abs(PosWork_knee)))
achilles.mech.data$ankleSNW=with(achilles.mech.data,abs(NegWork_ank+PosWork_ank)/(abs(NegWork_ank)+abs(PosWork_ank)))

#Calculate variables following Biewener et al 2004

#Avg EMA
achilles.mech.data$avg.hip.ema=achilles.mech.data$AreaGRF/achilles.mech.data$AreaHip
achilles.mech.data$avg.knee.ema=achilles.mech.data$AreaGRF/achilles.mech.data$AreaKnee
achilles.mech.data$avg.ank.ema=achilles.mech.data$AreaGRF/achilles.mech.data$AreaAnk

#Convert ankma to meters

achilles.mech.data$ankma.meters=achilles.mech.data$ankma/100

#Avg GRF load arm lengths

achilles.mech.data$avg.ank.R=(achilles.mech.data$AreaGRF*achilles.mech.data$meanrAnk)/achilles.mech.data$AreaAnk

#Subsets Data By Speed

sprint.achilles.mech.data=subset(achilles.mech.data,achilles.mech.data$Gait=='Sprint')
run.achilles.mech.data=subset(achilles.mech.data,achilles.mech.data$Gait=='Run')
jog.achilles.mech.data=subset(achilles.mech.data,achilles.mech.data$Gait=='Jog')
fw.achilles.mech.data=subset(achilles.mech.data,achilles.mech.data$Gait=='FastWalk')
walk.achilles.mech.data=subset(achilles.mech.data,achilles.mech.data$Gait=='Walking')

#Tendon Stress and Energy Storage

achilles.strain.model.data=subset(achilles.mech.data,select=c('Subject','Trial','Gait','avg.ank.R','AreaGRF','ankma','foot.length','ankma.meters','AreaAnk','Froude_COL'))
achilles.morph.data=subset(morph.data,select=c('Subject','tendon.length'))
achilles.strain.model.data=merge(achilles.strain.model.data,achilles.morph.data,all.x=T,all.y=T,by='Subject')
achilles.imagej.data=subset(imagej.data,select=c('Subject','tendon.area','tendon.area.sqm'))
achilles.strain.model.data=merge(achilles.strain.model.data,achilles.imagej.data,all.x=T,all.y=T,by='Subject')
achilles.strain.model.data=merge(achilles.strain.model.data,bm.data,all.x=T,all.y=T,by='Subject')
achilles.strain.model.data=merge(achilles.strain.model.data,peak.mech.data,all.x=T,all.y=T,by=c('Subject','Trial','Gait'))

#Create peak force data

peak.strain.model.data = merge(peak.mech.data,achilles.imagej.data,all.x=T,all.y=T,by='Subject')
peak.strain.model.data = merge(peak.strain.model.data,bm.data,all.x=T,all.y=T,by='Subject')
peak.strain.model.data = merge(peak.strain.model.data,achilles.morph.data,all.x=T,all.y=T,by=c('Subject'))
peak.strain.model.data = merge(peak.strain.model.data,ank.ma.only.data,all.x=T,all.y=T,by=c('Subject'))

as.numeric(peak.strain.model.data$peak.AnkForce)
as.numeric(peak.strain.model.data$tendon.area.sqm)
as.numeric(peak.strain.model.data$tendon.area)

#Mean stress
achilles.strain.model.data$tendon.stress=as.numeric(achilles.strain.model.data$AreaAnk)/as.numeric(achilles.strain.model.data$tendon.area.sqm)
achilles.strain.model.data$MPa=achilles.strain.model.data$tendon.stress/10^6
achilles.strain.model.data$peak.MPa=achilles.strain.model.data$tendon.stress/10^6
achilles.strain.model.data$MPa.BW=achilles.strain.model.data$MPa/achilles.strain.model.data$bm

#Mean strain
achilles.strain.model.data$tendon.length.m=achilles.strain.model.data$tendon.length/100
achilles.strain.model.data$strain=achilles.strain.model.data$MPa/819
achilles.strain.model.data$tendon.length.change=achilles.strain.model.data$strain*achilles.strain.model.data$tendon.length.m

#Mean energy storage - multiplied by 0.93 following Moore et al. 2017
achilles.strain.model.data$tendon.energy=0.93*(achilles.strain.model.data$tendon.length.change*(0.5*achilles.strain.model.data$AreaAnk))
achilles.strain.model.data$tendon.energy.bw=achilles.strain.model.data$tendon.energy/achilles.strain.model.data$bm

#Peak stress
peak.strain.model.data$peak.tendon.stress=as.numeric(peak.strain.model.data$peak.AnkForce)/as.numeric(peak.strain.model.data$tendon.area.sqm)
peak.strain.model.data$peak.MPa=peak.strain.model.data$peak.tendon.stress/10^6
peak.strain.model.data$peak.MPa.BW=peak.strain.model.data$peak.MPa/peak.strain.model.data$bm

#Peak strain
peak.strain.model.data$tendon.length.m=peak.strain.model.data$tendon.length/100
peak.strain.model.data$strain=peak.strain.model.data$peak.MPa/819
peak.strain.model.data$tendon.length.change=peak.strain.model.data$strain*peak.strain.model.data$tendon.length.m

#Peak energy storage - multiplied by 0.93 following Moore et al. 2017
peak.strain.model.data$tendon.energy=0.93*(peak.strain.model.data$tendon.length.change*(0.5*peak.strain.model.data$peak.AnkForce))
peak.strain.model.data$tendon.energy.bw=peak.strain.model.data$tendon.energy/peak.strain.model.data$bm

#Subset data

sprint.achilles.strain.model.data=subset(achilles.strain.model.data,achilles.strain.model.data$Gait=='Sprint')
run.achilles.strain.model.data=subset(achilles.strain.model.data,achilles.strain.model.data$Gait=='Run')
jog.achilles.strain.model.data=subset(achilles.strain.model.data,achilles.strain.model.data$Gait=='Jog')

sprint.peak.strain.model.data=subset(peak.strain.model.data,peak.strain.model.data$Gait=='Sprint')
run.peak.strain.model.data=subset(peak.strain.model.data,peak.strain.model.data$Gait=='Run')
jog.peak.strain.model.data=subset(peak.strain.model.data,peak.strain.model.data$Gait=='Jog')

#Subset one outlier point - impossibly high
sub.run.achilles.strain.model.data=subset(run.achilles.strain.model.data,run.achilles.strain.model.data$tendon.energy<4)

#Subset one outlier point - impossibly high
sub.run.peak.strain.model.data=subset(run.peak.strain.model.data,run.peak.strain.model.data$tendon.energy<1000)

########################
## Hypothesis Testing ##
########################

#_____TRICEPS SURAE MECHANICAL ADVANTAGE AND ELASTIC ENERGY RETURN_______________________.

#_______Mixed Effect Models____________________________________________________________.

#DATA FOR TABLE 3

#___Run

#Running trials - Ankle SNW vs ankma + tendon area + Avg Ank R + Area GRF (impulse) + Froude - body mass
SNW.run.fullmod=lme(scale(ankleSNW)~scale(ankma)+scale(tendon.area.sqm)+scale(avg.ank.R)+scale(AreaGRF)+scale(Froude_COL)+scale(bm),data=run.achilles.mech.data,random=~1|Subject,method='ML',na.action="na.omit")
anova(SNW.run.fullmod)
summary(SNW.run.fullmod)

#___Sprint

#Sprinting trials - Ankle SNW vs ankma + tendon area + Avg Ank R + Area GRF  (impulse) + Froude_COL + bm
SNW.sprint.fullmod=lme(scale(ankleSNW)~scale(ankma)+scale(tendon.area.sqm)+scale(avg.ank.R)+scale(AreaGRF)+scale(Froude_COL)+scale(bm),data=sprint.achilles.mech.data,random=~1|as.factor(Subject),method='ML', na.action="na.omit")
anova(SNW.sprint.fullmod)
summary(SNW.sprint.fullmod)

#___________Pearson's R______________________________________________________________________

#DATA FOR CORRELATIONS WITHIN THE BODY OF THE MANUSCRIPT

#Correlation between ankma and bm
cor.test(scaling.data$ankma,scaling.data$bm,method=c('pearson'),alternative="greater")

#Correlation between R ankle and AT moment arm length at sprint speeds

cor.test(sprint.achilles.mech.data$ankma,sprint.achilles.mech.data$avg.ank.R,method=c('pearson'))

#Correlation between foot length and ankle moment arm length

cor.test(scaling.data$foot.length,scaling.data$ankma,method=c('pearson'),alternative="greater")

#DATA FOR TABLE 2

#SNW values

cor.test(sprint.achilles.mech.data$ankma,sprint.achilles.mech.data$ankleSNW,method=c('pearson'),alternative="greater")
cor.test(jog.achilles.mech.data$ankma,jog.achilles.mech.data$ankleSNW,method=c('pearson'),alternative="greater")
cor.test(run.achilles.mech.data$ankma,run.achilles.mech.data$ankleSNW,method=c('pearson'),alternative="greater")
cor.test(walk.achilles.mech.data$ankma,walk.achilles.mech.data$ankleSNW,method=c('pearson'),alternative="greater")
cor.test(fw.achilles.mech.data$ankma,fw.achilles.mech.data$ankleSNW,method=c('pearson'),alternative="greater")

#Tendon stress
cor.test(sprint.achilles.strain.model.data$ankma,sprint.achilles.strain.model.data$MPa.BW,method=c('pearson'),alternative = "less")
cor.test(sub.run.achilles.strain.model.data$ankma,sub.run.achilles.strain.model.data$MPa.BW,method=c('pearson'),alternative = "less")

#Tendon energy
cor.test(sprint.achilles.strain.model.data$ankma,sprint.achilles.strain.model.data$tendon.energy.bw,method=c('pearson'),alternative = "less")
cor.test(sub.run.achilles.strain.model.data$ankma,sub.run.achilles.strain.model.data$tendon.energy.bw,method=c('pearson'),alternative = "less")


##################
## Summary Data ##
##################

mean.velocity.sprint = mean(sprint.achilles.mech.data$velocity)
sd.velocity.spring = sd(sprint.achilles.mech.data$velocity)

#Summary Statistics - Mean value for peak Tendon stress

mean.sprint.MPa=mean(sprint.peak.strain.model.data$peak.MPa)
mean.run.MPa=mean(sub.run.peak.strain.model.data$peak.MPa)

#Find subject with smallest AT moment arm
min.ma=min(imagej.data$ankma)
subject.min=imagej.data[imagej.data$ankma==min.ma, ]
subject.min.sprint.tendon.energy=subset(sprint.achilles.strain.model.data, sprint.achilles.strain.model.data$Subject==subject.min$Subject)
subject.min.peak.sprint.tendon.energy=subset(peak.strain.model.data, peak.strain.model.data$Subject==subject.min$Subject)

#Find subject with largest AT moment arm

max.ma=max(imagej.data$ankma)
subject.max=imagej.data[imagej.data$ankma==max.ma, ]
subject.max.sprint.tendon.energy=subset(sprint.achilles.strain.model.data, sprint.achilles.strain.model.data$Subject==subject.max$Subject)
subject.max.peak.sprint.tendon.energy=subset(peak.strain.model.data, peak.strain.model.data$Subject==subject.max$Subject)

#Maximum mass-specific tendon energy for subject with smallest AT moment arm
max.min.subject=max(subject.min.sprint.tendon.energy$tendon.energy.bw)
max.peak.min.subject=max(subject.min.peak.sprint.tendon.energy$tendon.energy.bw)

max.max.subject=max(subject.max.sprint.tendon.energy$tendon.energy.bw)
max.peak.max.subject=max(subject.max.peak.sprint.tendon.energy$tendon.energy.bw)

#Percentage difference between max values from smallest and largest AT moment arm lengths

perc.diff.sprint.tendon.energy.BW = (max.min.subject-max.max.subject)/max.min.subject
perc.diff.peak.sprint.tendon.energy.BW = (max.peak.min.subject-max.peak.max.subject)/max.peak.min.subject

#Create summary dataset

morph.summary.data=subset(morph.data,select=c('hip.height','foot.length','tendon.length','height','age','sex','Subject','bm'))

summary.data=merge(morph.summary.data,ank.ma.data,all.x=T,all.y=T,by='Subject')

#Create variable means and SD by speed

table.subset=subset(achilles.mech.data, select=c("Subject","Gait","Froude_COL","hipSNW","kneeSNW","ankleSNW","ankma","impulseHip",
                                                 "impulseKnee","impulseAnk"),na.rm=TRUE)

#Summary Table for Subject Info and AnkMA

morph.summary.table=subset(morph.data,select=c("Subject","age","sex","bm"))
ank.ma.cut=subset(ank.ma.data,select=c("Subject","ankma","tendon.area"))

morph.summary.table=merge(morph.summary.table,ank.ma.cut,all.x=T,all.y=T,by='Subject')

#DATA FOR TABLE 4 - Subject Morphometrics and Summary Statistics

morph.summary.table.compiled=data.frame('Male'=NA,'Female'=NA, 'Age Mean'=NA, 'Age SD'=NA,
                                        'BM Mean'=NA, 'BM SD'=NA, 'AT Moment Arm Mean'=NA, 
                                        'AT Moment Arm SD'=NA, 'AT Cross-Sectional Area Mean'=NA,
                                        'AT Cross-Sectional Area SD'=NA)

morph.summary.table.compiled$Male = sum(morph.summary.table$sex=='Male')
morph.summary.table.compiled$Female = sum(morph.summary.table$sex=="Female")
morph.summary.table.compiled$Age.Mean = round(mean(morph.summary.table$age, na.rm=TRUE),digits=2)
morph.summary.table.compiled$Age.SD = round(sd(morph.summary.table$age, na.rm=TRUE),digits=2)
morph.summary.table.compiled$BM.Mean = round(mean(morph.summary.table$bm, na.rm=TRUE),digits=2)
morph.summary.table.compiled$BM.SD = round(sd(morph.summary.table$bm, na.rm=TRUE),digits=2)
morph.summary.table.compiled$AT.Moment.Arm.Mean = round(mean(morph.summary.table$ankma, na.rm=TRUE),digits=2)
morph.summary.table.compiled$AT.Moment.Arm.SD = round(sd(morph.summary.table$ankma, na.rm=TRUE),digits=2)
morph.summary.table.compiled$AT.Cross.Sectional.Area.Mean = round(mean(morph.summary.table$tendon.area, na.rm=TRUE),digits=2)
morph.summary.table.compiled$AT.Cross.Sectional.Area.SD = round(sd(morph.summary.table$tendon.area, na.rm=TRUE),digits=2)

write.csv(morph.summary.table.compiled,file.path(achilles.folder.loc,'Tables','Table4_SubjectSummaryTable.csv'),row.names=F)
    
#TABLE 1 - Summary Table for Froude and SNW

SNW.Summary.Data <- ddply(table.subset, c("Gait"),summarise,
                                  froude.mean = round(mean(Froude_COL, na.rm=TRUE),digits=3),
                                  froude.sd = round(sd(Froude_COL, na.rm=TRUE),digits=3),
                                  hipSNW.mean = round(mean(hipSNW, na.rm=TRUE),digits=3),
                                  hipSNW.sd = round(sd(hipSNW, na.rm=TRUE),digits=3),
                                  kneeSNW.mean = round(mean(kneeSNW, na.rm=TRUE),digits=3),
                                  kneeSNW.sd = round(sd(kneeSNW, na.rm=TRUE),digits=3),
                                  ankleSNW.mean = round(mean(ankleSNW, na.rm=TRUE),digits=3),
                                  ankleSNW.sd   = round(sd(ankleSNW, na.rm=TRUE),digits=3)
                                  
)

#Rename gait labels

SNW.Summary.Data$Gait[SNW.Summary.Data$Gait=='Walking'] <- "Walk"
SNW.Summary.Data$Gait[SNW.Summary.Data$Gait=='FastWalk'] <- "Fast Walk"

#Change order from slow to fast speeds
table.order=c('Walk','Fast Walk','Jog','Run','Sprint')
SNW.Summary.Data.Update = SNW.Summary.Data %>% mutate(Gait = factor(Gait, levels = table.order)) %>%
    arrange(Gait)

write.csv(SNW.Summary.Data.Update,file.path(achilles.folder.loc,'Tables','Table1_Froude_SNW_Summary.csv'),row.names=F)

#DATA FOR SUPPLEMENTARY TABLES 1 AND 2 - Tendon Stress and Elastic Energy Storage

#Summary Table for Froude and SNW

#Subset tendon stress

sub.sprint.tendon.data=subset(sprint.achilles.strain.model.data,select=c('Subject','Trial','Side','Gait','MPa','MPa.BW','tendon.energy','tendon.energy.bw','tendon.length.change'))
sub.run.tendon.data=subset(sub.run.achilles.strain.model.data,select=c('Subject','Trial','Side','Gait','MPa','MPa.BW','tendon.energy','tendon.energy.bw','tendon.length.change'))

sub.sprint.peak.tendon.data=subset(sprint.peak.strain.model.data,select=c('Subject','Trial','Side','Gait','peak.MPa','peak.MPa.BW','tendon.energy','tendon.energy.bw','tendon.length.change'))
sub.run.peak.tendon.data=subset(sub.run.peak.strain.model.data,select=c('Subject','Trial','Side','Gait','peak.MPa','peak.MPa.BW','tendon.energy','tendon.energy.bw','tendon.length.change'))

summary.sprint.tendon.data <- ddply(sub.sprint.tendon.data, c("Subject","Gait"),summarise,
                          tendon.stress.mean = round(mean(MPa, na.rm=TRUE),digits=2),
                          tendon.stress.sd = round(sd(MPa, na.rm=TRUE),digits=2),
                          tendon.stress.bw.mean = round(mean(MPa.BW, na.rm=TRUE),digits=2),
                          tendon.stress.bw.sd = round(sd(MPa.BW, na.rm=TRUE),digits=2),
                          tendon.energy.mean = round(mean(tendon.energy, na.rm=TRUE),digits=2),
                          tendon.energy.sd = round(sd(tendon.energy, na.rm=TRUE),digits=2),
                          tendon.energy.bw.mean = round(mean(tendon.energy.bw, na.rm=TRUE),digits=4),
                          tendon.energy.bw.sd = round(sd(tendon.energy.bw, na.rm=TRUE),digits=4),
                          tendon.length.change.mean = round(mean(tendon.length.change, na.rm=TRUE),digits=4),
                          tendon.length.change.sd = round(sd(tendon.length.change, na.rm=TRUE),digits=4)
                          
)

summary.run.tendon.data <- ddply(sub.run.tendon.data, c("Subject","Gait"),summarise,
                                    tendon.stress.mean = round(mean(MPa, na.rm=TRUE),digits=2),
                                    tendon.stress.sd = round(sd(MPa, na.rm=TRUE),digits=2),
                                    tendon.stress.bw.mean = round(mean(MPa.BW, na.rm=TRUE),digits=2),
                                    tendon.stress.bw.sd = round(sd(MPa.BW, na.rm=TRUE),digits=2),
                                    tendon.energy.mean = round(mean(tendon.energy, na.rm=TRUE),digits=2),
                                    tendon.energy.sd = round(sd(tendon.energy, na.rm=TRUE),digits=2),
                                    tendon.energy.bw.mean = round(mean(tendon.energy.bw, na.rm=TRUE),digits=4),
                                    tendon.energy.bw.sd = round(sd(tendon.energy.bw, na.rm=TRUE),digits=4),
                                    tendon.length.change.mean = round(mean(tendon.length.change, na.rm=TRUE),digits=4),
                                    tendon.length.change.sd = round(sd(tendon.length.change, na.rm=TRUE),digits=4)
                                    
)

summary.tendon.data = rbind(summary.sprint.tendon.data,summary.run.tendon.data)
summary.tendon.data %>% arrange(Subject)

#Change order ascending by subject
subject.order=c('Subject1','Subject2','Subject3','Subject4','Subject5','Subject6','Subject7',
                'Subject8','Subject9','Subject10','Subject11','Subject12','Subject13','Subject14',
                'Subject15','Subject16','Subject17','Subject18','Subject19','Subject20','Subject21',
                'Subject22','Subject23','Subject24')
summary.tendon.data.Update = summary.tendon.data %>% mutate(Subject = factor(Subject, levels = subject.order)) %>%
  arrange(Subject)

write.csv(summary.tendon.data.Update,file.path(achilles.folder.loc,'Tables','TableS1_Tendon_Summary.csv'),row.names=F)

#Peak data

summary.sprint.peak.tendon.data <- ddply(sub.sprint.peak.tendon.data, c("Subject","Gait"),summarise,
                                    tendon.stress.mean = round(mean(peak.MPa, na.rm=TRUE),digits=2),
                                    tendon.stress.sd = round(sd(peak.MPa, na.rm=TRUE),digits=2),
                                    tendon.stress.bw.mean = round(mean(peak.MPa.BW, na.rm=TRUE),digits=2),
                                    tendon.stress.bw.sd = round(sd(peak.MPa.BW, na.rm=TRUE),digits=2),
                                    tendon.energy.mean = round(mean(tendon.energy, na.rm=TRUE),digits=2),
                                    tendon.energy.sd = round(sd(tendon.energy, na.rm=TRUE),digits=2),
                                    tendon.energy.bw.mean = round(mean(tendon.energy.bw, na.rm=TRUE),digits=4),
                                    tendon.energy.bw.sd = round(sd(tendon.energy.bw, na.rm=TRUE),digits=4),
                                    tendon.length.change.mean = round(mean(tendon.length.change, na.rm=TRUE),digits=4),
                                    tendon.length.change.sd = round(sd(tendon.length.change, na.rm=TRUE),digits=4)
                                    
)

summary.run.peak.tendon.data <- ddply(sub.run.peak.tendon.data, c("Subject","Gait"),summarise,
                                         tendon.stress.mean = round(mean(peak.MPa, na.rm=TRUE),digits=2),
                                         tendon.stress.sd = round(sd(peak.MPa, na.rm=TRUE),digits=2),
                                         tendon.stress.bw.mean = round(mean(peak.MPa.BW, na.rm=TRUE),digits=2),
                                         tendon.stress.bw.sd = round(sd(peak.MPa.BW, na.rm=TRUE),digits=2),
                                         tendon.energy.mean = round(mean(tendon.energy, na.rm=TRUE),digits=2),
                                         tendon.energy.sd = round(sd(tendon.energy, na.rm=TRUE),digits=2),
                                         tendon.energy.bw.mean = round(mean(tendon.energy.bw, na.rm=TRUE),digits=4),
                                         tendon.energy.bw.sd = round(sd(tendon.energy.bw, na.rm=TRUE),digits=4),
                                         tendon.length.change.mean = round(mean(tendon.length.change, na.rm=TRUE),digits=4),
                                         tendon.length.change.sd = round(sd(tendon.length.change, na.rm=TRUE),digits=4)
                                         
)

summary.peak.tendon.data = rbind(summary.sprint.peak.tendon.data,summary.run.peak.tendon.data)

summary.peak.tendon.data.Update = summary.peak.tendon.data %>% mutate(Subject = factor(Subject, levels = subject.order)) %>%
  arrange(Subject)

#Relabel Columns

write.csv(summary.peak.tendon.data.Update,file.path(achilles.folder.loc,'Tables','TableS2_Peak_Tendon_Summary.csv'),row.names=F)

###########
## Plots ##
###########

#Subset data to create density plots

boxplot.achilles.mech.data=subset(achilles.mech.data,select=c('Subject','hipSNW','kneeSNW','ankleSNW','Gait'))
boxplot.data=melt(boxplot.achilles.mech.data,id.vars=c('Subject','Gait'),measure.vars=c('hipSNW','kneeSNW','ankleSNW'))
boxplot.sub.data=subset(boxplot.data[which(boxplot.data$Gait=='Walking'| boxplot.data$Gait== 'FastWalk' | boxplot.data$Gait=='Jog' | boxplot.data$Gait== 'Run' | boxplot.data$Gait=='Sprint'),])
boxplot.sub.data=rename(boxplot.sub.data,c("variable"="Joint","value"="SNW"))
boxplot.sub.data$Joint=factor(boxplot.sub.data$Joint,levels=c("hipSNW","kneeSNW","ankleSNW"))

boxplot.sub.data$Gait[boxplot.sub.data$Gait=='Walking'] <- "Walk"
boxplot.sub.data$Gait[boxplot.sub.data$Gait=='FastWalk'] <- "Fast Walk"
boxplot.sub.data$Gait=factor(boxplot.sub.data$Gait,levels=c("Walk","Fast Walk","Jog","Run","Sprint"))
boxplot.sub.data$SNW=as.numeric(boxplot.sub.data$SNW)

#Fig 1 - SNW density plots by joint and speed

if (dev.cur()>1) {dev.off()}
setwd(file.path(achilles.folder.loc,'Figures'))
windows(width=5,height=5)
#if using Mac use quartz
#quartz(width=5,height=5)
par(mar=c(5,5,5,5)+0.1,xpd=F)

#Create grobs which will add labels to margin of plot
text_high = textGrob("Brake\ \nMotor-Like", gp=gpar(fontsize=10, fontface="bold"))
text_low = textGrob("Spring-Like", gp=gpar(fontsize=10, fontface="bold"))
#theme(plot.margin = unit(c(1,1,2,1), "lines")) - creates space below plot for grobs
#coord_cartesian(clip="off") - must be set to off

ggplot(boxplot.sub.data,aes(y=Gait,x=SNW,color=Joint,point_color=Joint,fill=Joint,height=..density..))+
  geom_density_ridges(
    jittered_points = TRUE, scale = .95, rel_min_height = .01,
    point_shape = "|", point_size = 3, size = 0.25,
    position = position_points_jitter(height = 0),alpha=0.4
  )+
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                     panel.grid.minor = element_blank(),axis.line = element_line(color = "black"),plot.title = element_text(face="bold",size=14,hjust = 0.5),plot.margin = unit(c(1,1,2,1), "lines"))+
  
  xlim(0,1)+
  scale_y_discrete(expand=c(0,0))+
  ylab("Speed")+
  scale_fill_manual(values=c("#4E84C4", "#293352", "#D55E00"),labels = c("Hip","Knee","Ankle"))+
  scale_color_manual(values=c("#4E84C4", "#293352", "#D55E00"),guide="none")+
  scale_discrete_manual("point_color",values=c("#4E84C4", "#293352", "#D55E00"),guide="none")+
  theme(legend.position="bottom",legend.direction="horizontal",legend.title = element_blank())+
  annotation_custom(text_high,xmin=2.00,xmax=-0.07,ymax=-0.25)+
  annotation_custom(text_low,xmin=0.00,xmax=-0.07,ymax=-0.25)+
  coord_cartesian(clip="off")

guides(shape = guide_legend(override.aes = list(size=5,shape=24,fill = c("#4E84C4", "#293352", "#D55E00"))))

dev.print(tiff,'Fig1_SNW_Density.tiff',width=5,height=5,units='in',res=600,compression = 'lzw')

dev.off()


#Fig 2 - Scatter plot of Ankle SNW and Achilles Tendon moment arm - Sprint and Run Speeds

if (dev.cur()>1) {dev.off()}

setwd(file.path(achilles.folder.loc,'Figures'))
windows(width=7,height=8)
#if using Mac use quartz
#quartz(width=7,height=8)

par(mar=c(5,5,5,5)+0.1,xpd=F)

p1= ggplot(run.achilles.mech.data,aes(x=ankma,y=ankleSNW))+
  geom_point()+
  ggtitle("Run")+
  geom_smooth(method=lm,se=TRUE,color='black')+
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                     panel.grid.minor = element_blank(),axis.line = element_line(color = "black"),plot.title = element_text(face="bold",size=14,hjust = 0.5))+
  ylim(0,1)+
  scale_y_continuous(breaks=c(0.00,0.25,0.50,0.75,1.00))+
  labs(x="Achilles Tendon Moment Arm (cm)",y="Ankle SNW")


p2 = ggplot(sprint.achilles.mech.data,aes(x=ankma,y=ankleSNW))+
  geom_point()+
  ggtitle("Sprint")+
  geom_smooth(method=lm,se=TRUE,color='black')+
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                     panel.grid.minor = element_blank(),axis.line = element_line(color = "black"),plot.title = element_text(face="bold",size=14,hjust = 0.5))+
  ylim(0,1)+
  labs(x="Achilles Tendon Moment Arm (cm)")+
  ylab(NULL)

plot_grid(p1,p2,align='v',ncol=2,labels="auto",rel_widths = c(1,1),rel_heights = c(1,1))
dev.print(tiff,'Fig2_AnkleSNW_Run_Sprint.tiff',width=8,height=5,units='in',res=900,bg='white')

dev.off()

#Fig 3 - Combined 4 panel plot - Tendon stress and elastic energy storage at run and sprint speeds

if (dev.cur()>1) {dev.off()}
setwd(file.path(achilles.folder.loc,'Figures'))
windows(width=8,height=5)
#if using Mac use quartz
#quartz(width=8,height=5)

p1= ggplot(sub.run.achilles.strain.model.data,aes(x=ankma,y=tendon.energy.bw))+
  geom_point()+
  ggtitle("Run")+
  geom_smooth(method=lm,se=TRUE,color='black')+
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                     panel.grid.minor = element_blank(),axis.line = element_line(color = "black"),plot.title = element_text(face="bold",size=14,hjust = 0.5))+
  ylab("Joules/kg")+
  xlab(NULL)


p2 = ggplot(sprint.achilles.strain.model.data,aes(x=ankma,y=tendon.energy.bw))+
  geom_point()+
  ggtitle("Sprint")+
  geom_smooth(method=lm,se=TRUE,color='black')+
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                     panel.grid.minor = element_blank(),axis.line = element_line(color = "black"),plot.title = element_text(face="bold",size=14,hjust = 0.5))+
  ylab(NULL)+
  xlab(NULL)

p3= ggplot(run.achilles.strain.model.data,aes(x=ankma,y=MPa.BW))+
  geom_point()+
  geom_smooth(method=lm,se=TRUE,color='black')+
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                     panel.grid.minor = element_blank(),axis.line = element_line(color = "black"),plot.title = element_text(face="bold",size=14,hjust = 0.5))+
  ylim(0,0.35)+
  labs(x="Achilles Tendon Moment Arm (cm)",y="MPa/kg")


p4 = ggplot(sprint.achilles.strain.model.data,aes(x=ankma,y=MPa.BW))+
  geom_point()+
  geom_smooth(method=lm,se=TRUE,color='black')+
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                     panel.grid.minor = element_blank(),axis.line = element_line(color = "black"),plot.title = element_text(face="bold",size=14,hjust = 0.5))+
  ylim(0,0.35)+
  labs(x="Achilles Tendon Moment Arm (cm)")+
  ylab(NULL)

plot_grid(p1,p2,p3,p4,align='v',ncol=2,labels="auto",rel_widths = c(1,1),rel_heights = c(1,1))

dev.print(tiff,'Fig3_Elastic_energy_tendon_stress.tiff',width=8,height=5,units='in',res=900,bg='white')

dev.off()

#Supplemental Figure 1 - Ankle Moment Arm Boxplot/Dotplot

if (dev.cur()>1) {dev.off()}

setwd(file.path(achilles.folder.loc,'Figures'))
windows(width=5,height=5)
#if using Mac use quartz
#quartz(width=5,height=5)

par(mar=c(5,5,5,5)+0.1,xpd=F)

ggplot(scaling.data,aes(x=NA,y=ankma))+
  geom_boxplot(width=0.25)+
  geom_point(position = position_jitter(width = .15), size = .75)+
  labs(y="Achilles Tendon Moment Arm (cm)")+
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                     panel.grid.minor = element_blank(),axis.line = element_line(color = "black"))+
  theme(axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank())

dev.print(tiff,'AnkMA.tiff',width=5,height=5,units='in',res=600,compression = 'lzw')

dev.off()